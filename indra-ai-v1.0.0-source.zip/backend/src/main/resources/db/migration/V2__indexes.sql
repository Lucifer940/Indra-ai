-- Flyway migration V2: additional indexes for performance
-- -----------------------------------------------------
-- 1. Faster memory lookups by category + importance
-- -----------------------------------------------------
CREATE INDEX IF NOT EXISTS idx_memories_user_cat_imp ON memories(user_id, category, importance DESC);

-- 2. Task overdue queries
-- -----------------------------------------------------
CREATE INDEX IF NOT EXISTS idx_tasks_user_due_rec ON tasks(user_id, recurring, due_at ASC);

-- 3. Conversation turn lookups
-- -----------------------------------------------------
CREATE INDEX IF NOT EXISTS idx_turns_user_conv_time ON conversation_turns(user_id, conversation_id, timestamp ASC);

-- -----------------------------------------------------
-- End of V2 indexes
-- -----------------------------------------------------
