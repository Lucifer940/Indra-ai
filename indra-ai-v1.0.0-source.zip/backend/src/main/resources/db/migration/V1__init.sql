-- Flyway migration V1: initial schema for INDRA AI backend
-- PostgreSQL / SQLite compatible (mostly; SQLite differences noted)

-- -----------------------------------------------------
-- 1. users table
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    display_name TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'USER',
    created_at TEXT NOT NULL
);

-- -----------------------------------------------------
-- 2. conversations table
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS conversations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    conversation_id TEXT NOT NULL,
    title TEXT,
    created_at TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- -----------------------------------------------------
-- 3. conversation_turns table
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS conversation_turns (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    conversation_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    role TEXT NOT NULL,          -- 'user' or 'assistant'
    content TEXT NOT NULL,
    timestamp TEXT NOT NULL,
    FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE
);

-- -----------------------------------------------------
-- 4. memories table
-- -----------------------------------------------------
-- Content is stored ENCRYPTED (AES-256-GCM blob). The encryption key
-- is INDRA_MEMORY_ENCRYPTION_KEY (32-byte base64 env var). Do NOT store
-- passwords or secrets as memories; the backend will reject them.
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS memories (
    id TEXT NOT NULL PRIMARY KEY,           -- base64-encoded UUID
    user_id INTEGER NOT NULL,
    content_encrypted TEXT NOT NULL,        -- base64 blob: nonce|ciphertext|tag
    category TEXT,
    importance REAL NOT NULL DEFAULT 0.5,
    created_at TEXT NOT NULL,
    last_accessed_at TEXT,
    access_count INTEGER NOT NULL DEFAULT 0,
    CHECK (importance >= 0.0 AND importance <= 1.0)
);

-- -----------------------------------------------------
-- 5. tasks table
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS tasks (
    id TEXT NOT NULL PRIMARY KEY,             -- base64-encoded UUID
    user_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    due_at TEXT,
    reminder_at TEXT,
    recurring INTEGER NOT NULL DEFAULT 0,     -- 0/1
    recurrence_pattern TEXT,
    completed INTEGER NOT NULL DEFAULT 0,     -- 0/1
    completed_at TEXT,
    created_at TEXT NOT NULL
);

-- -----------------------------------------------------
-- 6. index: user lookups
-- -----------------------------------------------------
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_conversations_user_id ON conversations(user_id);
CREATE INDEX IF NOT EXISTS idx_turns_conversation_id ON conversation_turns(conversation_id);
CREATE INDEX IF NOT EXISTS idx_memories_user_id ON memories(user_id);
CREATE INDEX IF NOT EXISTS idx_tasks_user_id ON tasks(user_id);
CREATE INDEX IF NOT EXISTS idx_tasks_completed_due ON tasks(completed, due_at);

-- -----------------------------------------------------
-- 7. seed a default admin user (password: change-me-on-first-use)
-- -----------------------------------------------------
-- Password is a PLACEHOLDER BCrypt hash. Replace with a proper hash
-- after first login, or use the register endpoint.
-- The email 'admin@indra.ai' is promoted to ADMIN role after registration.
-- -----------------------------------------------------
INSERT OR IGNORE INTO users (email, password_hash, display_name, role, created_at)
VALUES (
    'admin@indra.ai',
    '$2a$10$placeholderHashReplaceMeWithRealBCrypt', -- 10 is BCrypt cost factor; placeholder only
    'INDRA AI Administrator',
    'ADMIN',
    datetime('now')
);

-- -----------------------------------------------------
-- End of V1 initialization
-- -----------------------------------------------------
