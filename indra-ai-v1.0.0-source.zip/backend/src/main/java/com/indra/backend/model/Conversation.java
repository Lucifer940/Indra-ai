package com.indra.backend.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "conversations")
public class Conversation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "user_id", nullable = false)
    private Long userId; // denormalized for quick lookup

    @Column(name = "conversation_id", nullable = false) // UUID the client sends / we generate
    private String conversationId;

    @Column(name = "title")
    private String title; // e.g. "Daily chat" or null

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    @OneToMany(mappedBy = "conversation", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<ConversationTurn> turns = new ArrayList<>();

    // Constructors / getters / setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public String getConversationId() { return conversationId; }
    public void setConversationId(String conversationId) { this.conversationId = conversationId; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public List<ConversationTurn> getTurns() { return turns; }
    public void setTurns(List<ConversationTurn> turns) { this.turns = turns; }

    public void addTurn(ConversationTurn turn) {
        turns.add(turn);
        turn.setConversation(this);
    }
}
