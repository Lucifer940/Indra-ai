package com.indra.backend.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.util.Base64;

/**
 * Spring Security configuration for INDRA AI backend.
 * - JWT stateless filter (placeholder: to be wired with a JWT filter bean)
 * - Session creation stateless (mobile + desktop apps use JWT in Authorization header)
 * - CSRF disabled for API-only application
 * - Permissions scoped by user JWT subject
 */
@Configuration
// Deprecated method kept for Spring Boot 2.7 compatibility; modern code uses SecurityFilterChain.
@EnableGlobalMethodSecurity(prePostEnabled = true, securedEnabled = true)
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    // The JWT secret is read from environment; we expose a bean for the filter.
    // In production, set INDRA_JWT_SECRET in the environment (≥32 random bytes, base64).
    @Bean
    public SecretKey jwtSecretKey() {
        String b64 = System.getenv("INDRA_JWT_SECRET");
        if (b64 == null || b64.trim().isEmpty()) {
            // Dev fallback — NEVER use in production
            b64 = "change-me-to-a-long-random-secret-at-least-32-bytes-base64-encoded";
        }
        byte[] decoded = Base64.getDecoder().decode(b64);
        if (decoded.length < 32) {
            throw new IllegalStateException(
                    "INDRA_JWT_SECRET must decode to at least 32 bytes; got " + decoded.length);
        }
        return new SecretKeySpec(decoded, "HmacSHA256");
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
                .csrf().disable()
                .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                .and()
                .authorizeRequests()
                .antMatchers("/api/auth/**", "/api/health", "/api/public/**").permitAll()
                .antMatchers("/api/admin/**").hasRole("ADMIN")
                .anyRequest().authenticated()
                .and()
                .addFilterBefore(new JwtAuthenticationFilter(), UsernamePasswordAuthenticationFilter.class);
    }
}

/* -----------------------------------------------------------------
 *  JwtAuthenticationFilter — skeleton; the full implementation would validate
 *  the JWT token from the Authorization header, populate the Spring security
 *  context, and reject invalid/missing tokens. For brevity the filter is referenced
 *  but its body is in a separate file that will be created when the full project
 *  is assembled. The important thing is the filter is registered in the chain.
 * -----------------------------------------------------------------*/
