package com.indra.backend.repository;

import com.indra.backend.model.Memory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MemoryRepository extends JpaRepository<Memory, String> {

    @Query("SELECT m FROM Memory m WHERE m.userId = :userId AND m.category = :category")
    List<Memory> findByUserIdAndCategory(@Param("userId") Long userId, @Param("category") String category);

    @Query("SELECT m FROM Memory m WHERE m.userId = :userId ORDER BY m.importance DESC, m.createdAt DESC")
    List<Memory> findByUserIdOrderByImportanceCreatedAt(@Param("userId") Long userId);

    @Query("SELECT m FROM Memory m WHERE m.id = :id AND m.userId = :userId")
    Memory findByIdAndUserId(@Param("id") String id, @Param("userId") Long userId);
}
