package com.indra.backend.service;

import com.indra.backend.model.Memory;
import com.indra.backend.repository.MemoryRepository;
import com.indra.sharedcore.model.MemoryItem;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class MemoryService {

    @Value("${INDRA_MEMORY_ENCRYPTION_KEY:}")
    private String memoryEncryptionKeyB64;

    private final MemoryRepository memoryRepository;

    public MemoryService(MemoryRepository memoryRepository) {
        this.memoryRepository = memoryRepository;
    }

    /** Save a new memory item (content encrypted before DB write). */
    public MemoryItemDto saveMemory(MemoryItemDto memoryDto) throws Exception {
        // Encrypt the content
        Crypto crypto = new Crypto();
        String encrypted = crypto.encryptString(memoryDto.getContent(), memoryEncryptionKeyB64);

        Memory memory = new Memory();
        memory.setUserId(memoryDto.getUserId());
        memory.setCategory(memoryDto.getCategory());
        memory.setImportance(memoryDto.getImportance());
        memory.setContentEncrypted(encrypted);

        // ID is generated in Memory constructor (base64 UUID)
        Memory saved = memoryRepository.save(memory);

        // Return DTO
        MemoryItemDto dto = new MemoryItemDto();
        dto.setId(saved.getId());
        dto.setUserId(saved.getUserId());
        dto.setContent(memoryDto.getContent()); // keep plaintext in DTO for UI, but warn
        dto.setCategory(saved.getCategory());
        dto.setImportance(saved.getImportance());
        dto.setCreatedAt(saved.getCreatedAt());
        dto.setLastAccessedAt(saved.getLastAccessedAt());
        dto.setAccessCount(saved.getAccessCount());
        return dto;
    }

    /** Load memories for a user, optionally filtered by category and minimum importance. */
    public List<MemoryItemDto> loadMemories(Long userId, String category, double minImportance) throws Exception {
        List<Memory> memories;
        if (category != null && !category.isEmpty()) {
            memories = memoryRepository.findByUserIdAndCategory(userId, category);
        } else {
            memories = memoryRepository.findByUserIdOrderByImportanceCreatedAt(userId);
        }

        Crypto crypto = new Crypto();
        return memories.stream().map(m -> {
            try {
                MemoryItemDto dto = new MemoryItemDto();
                dto.setId(m.getId());
                dto.setUserId(m.getUserId());
                // Decrypt content for display (this is safe because we're in a trusted backend context)
                dto.setContent(crypto.decryptString(m.getContentEncrypted(), memoryEncryptionKeyB64));
                dto.setCategory(m.getCategory());
                dto.setImportance(m.getImportance());
                dto.setCreatedAt(m.getCreatedAt());
                dto.setLastAccessedAt(m.getLastAccessedAt());
                dto.setAccessCount(m.getAccessCount());
                return dto;
            } catch (Exception e) {
                throw new RuntimeException("Failed to decrypt memory " + m.getId(), e);
            }
        }).collect(Collectors.toList());
    }

    /** Update a memory's importance or category. */
    public MemoryItemDto updateMemory(String memoryId, Long userId, MemoryItemDto updates) throws Exception {
        Memory memory = memoryRepository.findByIdAndUserId(memoryId, userId)
                .orElseThrow(() -> new IllegalArgumentException("Memory not found or access denied: " + memoryId));

        if (updates.getImportance() != null) {
            memory.setImportance(updates.getImportance());
        }
        if (updates.getCategory() != null) {
            memory.setCategory(updates.getCategory());
        }
        // Note: content re-encryption only if content changes — omitted for brevity.

        Memory saved = memoryRepository.save(memory);

        MemoryItemDto dto = new MemoryItemDto();
        dto.setId(saved.getId());
        dto.setUserId(saved.getUserId());
        dto.setContent(saved.getContentEncrypted() != null ? "***encrypted***" : null); // don't expose raw blob
        dto.setCategory(saved.getCategory());
        dto.setImportance(saved.getImportance());
        dto.setCreatedAt(saved.getCreatedAt());
        dto.setLastAccessedAt(saved.getLastAccessedAt());
        dto.setAccessCount(saved.getAccessCount());
        return dto;
    }

    /** Delete a specific memory. */
    public void deleteMemory(String memoryId, Long userId) {
        memoryRepository.findByIdAndUserId(memoryId, userId)
                .orElseThrow(() -> new IllegalArgumentException("Memory not found or access denied: " + memoryId));
        memoryRepository.deleteById(memoryId);
    }

    /** Clear all memories for a user. */
    public void clearAllMemories(Long userId) {
        memoryRepository.deleteByUserId(userId);
    }
}

/* MemoryItemDto is a simple DTO transferred to the UI; it mirrors MemoryItem from shared-core
   but with decrypted content. The backend never sends the raw encrypted blob to the client
   in a ChatReply; the UI shows decrypted text. */
