package com.indra.backend.controller;

import com.indra.backend.model.*;
import com.indra.backend.service.CryptoService;
import com.indra.sharedcore.model.Personality;
import com.indra.sharedcore.model.ConversationTurn;
import com.indra.sharedcore.util.Crypto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.*;
import java.net.*;
import java.time.*;
import java.util.*;
import java.util.stream.*;

// DTOs for chat request/response
class ChatRequest {
    private String message;
    private String personality; // e.g. "Friendly"
    private String languageCode; // "en" or "ne"
    private String conversationId;
    private Long userId;

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
    public String getPersonality() { return personality; }
    public void setPersonality(String personality) { this.personality = personality; }
    public String getLanguageCode() { return languageCode; }
    public void setLanguageCode(String languageCode) { this.languageCode = languageCode; }
    public String getConversationId() { return conversationId; }
    public void setConversationId(String conversationId) { this.conversationId = conversationId; }
    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
}

class ChatReply {
    private String reply;
    private Personality personality;
    private String languageCode;
    private String conversationId;
    private LocalDateTime timestamp;

    public ChatReply() {}

    public ChatReply(String reply, Personality personality, String languageCode, String conversationId) {
        this.reply = reply;
        this.personality = personality;
        this.languageCode = languageCode;
        this.conversationId = conversationId;
        this.timestamp = LocalDateTime.now();
    }

    public String getReply() { return reply; }
    public void setReply(String reply) { this.reply = reply; }
    public Personality getPersonality() { return personality; }
    public void setPersonality(Personality personality) { this.personality = personality; }
    public String getLanguageCode() { return languageCode; }
    public void setLanguageCode(String languageCode) { this.languageCode = languageCode; }
    public String getConversationId() { return conversationId; }
    public void setConversationId(String conversationId) { this.conversationId = conversationId; }
    public LocalDateTime getTimestamp() { return timestamp; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }
}

/**
 * INDRA AI REST API controller — chat endpoint.
 * All AI keys stay server-side. The system prompt steers personality.
 * Language selection ("en"/"ne") is passed through; the AI model handles it.
 */
@RestController
@RequestMapping("/api/chat")
public class ChatController {

    @Autowired
    private CryptoService cryptoService;

    private static final String AI_MODEL = System.getenv("INDRA_AI_MODEL") != null
            ? System.getenv("INDRA_AI_MODEL") : "gpt-4o-mini";
    private static final String AI_BASE_URL = System.getenv("INDRA_AI_BASE_URL") != null
            ? System.getenv("INDRA_AI_BASE_URL") : "https://api.openai.com/v1";
    private final ObjectMapper objectMapper = new ObjectMapper();

    @PostMapping
    public ResponseEntity<ChatReply> chat(
            @RequestBody ChatRequest request,
            @RequestHeader(value = "Authorization", required = false) String authHeader) {

        // 1) Auth check (placeholder — production uses JwtAuthenticationFilter- populated security context)
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            ChatReply errorReply = new ChatReply("Authentication required", Personality.FRIENDLY, "en", request.getConversationId());
            return ResponseEntity.status(401).body(errorReply);
        }

        String message = request.getMessage();
        Personality personality = Personality.fromDisplayName(request.getPersonality());
        if (personality == Personality.UNSET) personality = Personality.FRIENDLY;
        String languageCode = request.getLanguageCode() != null ? request.getLanguageCode() : "en";

        // 2) Build system prompt from personality
        String systemPrompt = buildSystemPrompt(personality);

        // 3) Call AI provider
        String aiReply = callAiProvider(message, systemPrompt, languageCode);

        // 4) Build reply DTO
        ChatReply reply = new ChatReply(aiReply, personality, languageCode, request.getConversationId());
        return ResponseEntity.ok(reply);
    }

    /** Append relevant memories for the user as part of the system prompt. */
    private String buildSystemPrompt(Personality personality) {
        StringBuilder sb = new StringBuilder();
        sb.append(personality.getSystemPromptPrefix());
        // TODO: fetch user memories and append "User facts: ..."
        // For v1.0.0 we keep it simple; memory integration is a future enhancement.
        return sb.toString();
    }

    /** Call the AI provider (OpenAI-compatible) and return the reply text. */
    private String callAiProvider(String userMessage, String systemPrompt, String languageCode) {
        try {
            // Build JSON payload for OpenAI Chat Completions API
            Map<String, Object> messages = new LinkedHashMap<>();
            messages.put("role", "system");
            messages.put("content", systemPrompt);

            Map<String, Object> userMsg = new LinkedHashMap<>();
            userMsg.put("role", "user");
            userMsg.put("content", userMessage);

            Map<String, Object> payload = new LinkedHashMap<>();
            payload.put("model", AI_MODEL);
            payload.put("messages", Arrays.asList(messages, userMsg));
            payload.put("temperature", 0.7);
            payload.put("stream", false); // single response

            // Build HTTP request
            URL url = new URL(AI_BASE_URL + "/chat/completions");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Authorization", "Bearer " + System.getenv("INDRA_AI_API_KEY"));
            conn.setRequestProperty("Content-Type", "application/json; utf-8");
            conn.setRequestProperty("Accept", "application/json");
            conn.setDoOutput(true);

            try (OutputStream os = conn.getOutputStream()) {
                byte[] input = objectMapper.writeValueAsBytes(payload);
                os.write(input, 0, input.length);
            }

            int responseCode = conn.getResponseCode();
            if (responseCode != 200) {
                try (Scanner scanner = new Scanner(conn.getErrorStream())) {
                    String errorBody = scanner.useDelimiter("\\A").next();
                    throw new RuntimeException("AI provider error " + responseCode + ": " + errorBody);
                }
            }

            // Parse response
            try (Scanner scanner = new Scanner(conn.getInputStream(), "UTF-8")) {
                scanner.useDelimiter("\\A");
                String responseBody = scanner.next();
                JsonNode root = objectMapper.readTree(responseBody);
                if (root.has("choices") && root.get("choices").size() > 0) {
                    JsonNode choice = root.get("choices").get(0);
                    if (choice.has("message") && choice.get("message").has("content")) {
                        return choice.get("message").get("content").asText();
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            return "I'm having trouble connecting to the AI brain right now. Please try again in a moment.";
        }

        return "I received an empty response from the AI provider.";
    }
}

/* ObjectMapper and JsonNode imports from com.fasterxml.jackson.databind and .tree.
   The AI provider key (INDRA_AI_API_KEY) is read from the backend environment only —
   never in the Android or Windows app code or manifests.
   The chat endpoint is the core AI proxy; all other endpoints (memory, tasks, devices)
   follow the same pattern of backend-only secrets. */
