package com.indra.backend.controller;

import com.indra.backend.model.User;
import com.indra.backend.model.UserDto;
import com.indra.backend.repository.UserRepository;
import com.indra.backend.service.CryptoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.security.SecureRandom;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private CryptoService cryptoService; // for password BCrypt (simplified)

    // In production, use Spring Security BCryptPasswordEncoder.
    // Here we use a simple placeholder; replace with BCrypt in real deployment.

    @PostMapping("/register")
    public ResponseEntity<UserDto> register(@RequestBody UserRegistrationRequest req) {
        if (userRepository.findByEmail(req.getEmail()).isPresent()) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body(new UserDto(null, "Email already registered"));
        }

        User user = new User();
        user.setEmail(req.getEmail());
        // Placeholder password hash — replace with BCrypt.encode(password) in production
        user.setPasswordHash("PLACEHOLDER_BCRYPT_HASH:" + req.getPassword());
        user.setDisplayName(req.getDisplayName());
        user.setRole(User.Role.USER);
        user.setCreatedAt(java.time.LocalDateTime.now());

        userRepository.save(user);

        UserDto dto = new UserDto(user.getId(), user.getEmail(), user.getDisplayName(), user.getRole());
        return ResponseEntity.ok(dto);
    }

    @PostMapping("/login")
    public ResponseEntity<UserDto> login(@RequestBody UserLoginRequest req) {
        // In production: query user by email, verify BCrypt, generate JWT.
        // Placeholder: accept any password for the given email.
        User user = userRepository.findByEmail(req.getEmail())
                .orElseThrow(() -> new RuntimeException("User not found"));

        // Placeholder check — in real code: PasswordEncoder.matches(req.getPassword(), user.getPasswordHash())
        if (!req.getPassword().isEmpty()) {
            // Accept any non-empty password for now
        }

        UserDto dto = new UserDto(user.getId(), user.getEmail(), user.getDisplayName(), user.getRole());
        return ResponseEntity.ok(dto);
    }

    @PostMapping("/logout")
    public ResponseEntity<Void> logout(@RequestHeader(value = "Authorization", required = false) String authHeader) {
        // In production: invalidate server-side token store (e.g., Redis).
        // Stateless JWT: logout is client-side (clear the token).
        return ResponseEntity.ok(null);
    }

    // --- DTOs ---

    static class UserRegistrationRequest {
        private String email;
        private String password;
        private String displayName;

        public String getEmail() { return email; }
        public void setEmail(String email) { this.email = email; }
        public String getPassword() { return password; }
        public void setPassword(String password) { this.password = password; }
        public String getDisplayName() { return displayName; }
        public void setDisplayName(String displayName) { this.displayName = displayName; }
    }

    static class UserLoginRequest {
        private String email;
        private String password;

        public String getEmail() { return email; }
        public void setEmail(String email) { this.email = email; }
        public String getPassword() { return password; }
        public void setPassword(String password) { this.password = password; }
    }

    static class UserDto {
        private Long id;
        private String email;
        private String displayName;
        private User.Role role;

        public UserDto() {}

        public UserDto(Long id, String email, String displayName, Role role) {
            this.id = id;
            this.email = email;
            this.displayName = displayName;
            this.role = role;
        }

        public Long getId() { return id; }
        public String getEmail() { return email; }
        public String getDisplayName() { return displayName; }
        public Role getRole() { return role; }
    }
}
