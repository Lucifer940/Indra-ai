package com.indra.backend.controller;

import com.indra.backend.model.Memory;
import com.indra.backend.service.MemoryService;
import com.indra.sharedcore.model.MemoryItemDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/memories")
public class MemoryController {

    @Autowired
    private MemoryService memoryService;

    @PostMapping
    public ResponseEntity<MemoryItemDto> saveMemory(@RequestBody MemoryItemDto memoryDto,
                                                    @RequestHeader(value = "Authorization", required = false) String authHeader) {
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            return ResponseEntity.status(401).body(null);
        }
        try {
            MemoryItemDto saved = memoryService.saveMemory(memoryDto);
            return ResponseEntity.ok(saved);
        } catch (Exception e) {
            return ResponseEntity.status(500).body(null);
        }
    }

    @GetMapping
    public ResponseEntity<List<MemoryItemDto>> loadMemories(
            @RequestParam(value = "category", required = false) String category,
            @RequestParam(value = "minImportance", defaultValue = "0.0") double minImportance,
            @RequestHeader(value = "Authorization", required = false) String authHeader) {
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            return ResponseEntity.status(401).body(null);
        }
        try {
            Long userId = 1L; // placeholder: extract from JWT in production
            List<MemoryItemDto> memories = memoryService.loadMemories(userId, category, minImportance);
            return ResponseEntity.ok(memories);
        } catch (Exception e) {
            return ResponseEntity.status(500).body(null);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<MemoryItemDto> updateMemory(@PathVariable String id,
                                                      @RequestBody MemoryItemDto updates,
                                                      @RequestHeader(value = "Authorization", required = false) String authHeader) {
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            return ResponseEntity.status(401).body(null);
        }
        try {
            Long userId = 1L; // placeholder
            MemoryItemDto updated = memoryService.updateMemory(id, userId, updates);
            return ResponseEntity.ok(updated);
        } catch (Exception e) {
            return ResponseEntity.status(500).body(null);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteMemory(@PathVariable String id,
                                             @RequestHeader(value = "Authorization", required = false) String authHeader) {
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            return ResponseEntity.status(401).body(null);
        }
        try {
            Long userId = 1L; // placeholder
            memoryService.deleteMemory(id, userId);
            return ResponseEntity.ok(null);
        } catch (Exception e) {
            return ResponseEntity.status(500).body(null);
        }
    }
}
