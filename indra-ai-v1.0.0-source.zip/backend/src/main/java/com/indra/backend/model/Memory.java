package com.indra.backend.model;

import jakarta.persistence.*;
import java.util.UUID;
import java.util.Base64;

/**
 * Long-term memory item.
 * Content is encrypted (AES-256-GCM) BEFORE it is written to the DB column.
 * The encryption key is INDRA_MEMORY_ENCRYPTION_KEY (32-byte base64 env var).
 * The encrypted blob stored in the DB has the format:
 *   b64(nonce || ciphertext || tag) — Sun JDK convention (tag appended to doFinal output).
 */
@Entity
@Table(name = "memories")
public class Memory {

    @Id
    @Column(name = "id", nullable = false, updatable = false)
    private String id; // base64-encoded UUID

    @Column(name = "user_id", nullable = false)
    private Long userId;

    // Encrypted content — stored as TEXT (base64 blob)
    @Column(name = "content_encrypted", columnDefinition = "TEXT", nullable = false)
    private String contentEncrypted;

    @Column(name = "category")
    private String category;

    @Column(name = "importance")
    private double importance; // 0.0 – 1.0

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    @Column(name = "last_accessed_at")
    private LocalDateTime lastAccessedAt;

    @Column(name = "access_count")
    private int accessCount;

    // Constructors
    public Memory() {
        this.id = Base64.getEncoder().encodeToString(UUID.randomUUID().toString().getBytes(java.nio.charset.StandardCharsets.US_ASCII));
        this.createdAt = java.time.LocalDateTime.now();
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public String getContentEncrypted() { return contentEncrypted; }
    public void setContentEncrypted(String contentEncrypted) { this.contentEncrypted = contentEncrypted; }

    public String getDecryptedContent(Crypto crypto, String encryptionKeyB64) throws Exception {
        return crypto.decryptString(this.contentEncrypted, encryptionKeyB64);
    }

    public void setEncryptedContent(Crypto crypto, String plaintext, String encryptionKeyB64) throws Exception {
        this.contentEncrypted = crypto.encryptString(plaintext, encryptionKeyB64);
        if (this.createdAt == null) this.createdAt = java.time.LocalDateTime.now();
    }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public double getImportance() { return importance; }
    public void setImportance(double importance) { this.importance = importance; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public LocalDateTime getLastAccessedAt() { return lastAccessedAt; }
    public void setLastAccessedAt(LocalDateTime lastAccessedAt) { this.lastAccessedAt = lastAccessedAt; }

    public int getAccessCount() { return accessCount; }
    public void setAccessCount(int accessCount) { this.accessCount = accessCount; }
}
