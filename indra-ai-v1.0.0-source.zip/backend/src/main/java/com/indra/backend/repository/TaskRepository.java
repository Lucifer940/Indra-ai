package com.indra.backend.repository;

import com.indra.backend.model.Task;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TaskRepository extends JpaRepository<Task, String> {

    @Query("SELECT t FROM Task t WHERE t.userId = :userId ORDER BY t.dueAt ASC, t.createdAt DESC")
    List<Task> findByUserIdOrderByDueAt(@Param("userId") Long userId);

    @Query("SELECT t FROM Task t WHERE t.id = :id AND t.userId = :userId")
    Task findByIdAndUserId(@Param("id") String id, @Param("userId") Long userId);

    @Query("SELECT t FROM Task t WHERE t.completed = false AND t.dueAt <= :now ORDER BY t.dueAt ASC")
    List<Task> findOverdueTasks(@Param("userId") Long userId, @Param("now") LocalDateTime now);
}
