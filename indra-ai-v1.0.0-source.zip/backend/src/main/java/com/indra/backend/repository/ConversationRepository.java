package com.indra.backend.repository;

import com.indra.backend.model.Conversation;
import com.indra.backend.model.ConversationTurn;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ConversationRepository extends JpaRepository<Conversation, Long> {

    @Query("SELECT c FROM Conversation c WHERE c.userId = :userId AND c.conversationId = :conversationId")
    Conversation findByUserIdAndConversationId(@Param("userId") Long userId, @Param("conversationId") String conversationId);

    @Query("SELECT t FROM ConversationTurn t WHERE t.conversationId = :conversationId ORDER BY t.timestamp ASC")
    List<ConversationTurn> findTurnsByConversationId(@Param("conversationId") String conversationId);

    @Query("SELECT t FROM ConversationTurn t WHERE t.userId = :userId AND t.role = 'assistant' ORDER BY t.timestamp DESC")
    List<ConversationTurn> getRecentAssistantTurns(@Param("userId") Long userId, @Param("conversationId") String conversationId);
}
