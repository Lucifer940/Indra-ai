package com.indra.backend;

import com.indra.backend.config.SecurityConfig;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;

@SpringBootApplication
@Import(SecurityConfig.class)
public class IndraAiBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(IndraAiBackendApplication.class, args);
    }
}
