package com.indra.backend.service;

import com.indra.sharedcore.util.Crypto;
import com.indra.backend.model.Memory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import java.util.UUID;
import java.util.Base64;

@Service
public class CryptoService {

    @Value("${INDRA_MEMORY_ENCRYPTION_KEY:}")
    private String memoryEncryptionKeyB64;

    private final Crypto crypto = new Crypto();

    /** Generate a new encryption key and return its base64 string (for admin use). */
    public String generateEncryptionKeyB64() {
        return Crypto.generateKeyB64();
    }

    /** Encrypt a plaintext memory content and return the base64 blob. */
    public String encryptContent(String plaintext) throws Exception {
        if (memoryEncryptionKeyB64 == null || memoryEncryptionKeyB64.trim().isEmpty()) {
            throw new IllegalStateException("INDRA_MEMORY_ENCRYPTION_KEY not configured");
        }
        return Crypto.encryptString(plaintext, memoryEncryptionKeyB64);
    }

    /** Decrypt a memory content blob. */
    public String decryptContent(String cryptoBlob) throws Exception {
        if (memoryEncryptionKeyB64 == null || memoryEncryptionKeyB64.trim().isEmpty()) {
            throw new IllegalStateException("INDRA_MEMORY_ENCRYPTION_KEY not configured");
        }
        return Crypto.decryptString(cryptoBlob, memoryEncryptionKeyB64);
    }

    /** Create a new Memory entity with encrypted content. */
    public Memory createMemory(String userId, String plaintext, String category) throws Exception {
        Memory mem = new Memory();
        mem.setUserId(Long.parseLong(userId));
        mem.setCategory(category);
        mem.setImportance(0.5); // default
        mem.setEncryptedContent(crypto.encryptString(plaintext, memoryEncryptionKeyB64));
        // id is auto-generated in Memory constructor (base64 UUID)
        return mem;
    }
}
