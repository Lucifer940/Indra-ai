package com.indra.backend.service;

import com.indra.backend.model.Task;
import com.indra.backend.repository.TaskRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class TaskService {

    @Value("${INDRA_MEMORY_ENCRYPTION_KEY:}") // reuse same env placeholder, or add INDRA_TASK_KEY
    private String taskKeyB64; // placeholder — could be same as memory key or different

    private final TaskRepository taskRepository;

    public TaskService(TaskRepository taskRepository) {
        this.taskRepository = taskRepository;
    }

    /** Create a new task/reminder/alarm. */
    public Task createTask(Task task) {
        if (task.getId() == null) {
            String uuid = java.util.UUID.randomUUID().toString();
            task.setId(java.util.Base64.getEncoder().encodeToString(uuid.getBytes(java.nio.charset.StandardCharsets.US_ASCII)));
        }
        if (task.getCreatedAt() == null) {
            task.setCreatedAt(LocalDateTime.now());
        }
        if (!task.isCompleted()) {
            task.setCompletedAt(null);
        }
        return taskRepository.save(task);
    }

    /** Load tasks for a user. */
    public List<Task> loadTasks(Long userId) {
        return taskRepository.findByUserIdOrderByDueAt(userId);
    }

    /** Mark a task as complete. */
    public Task completeTask(String taskId, Long userId) {
        Task task = taskRepository.findByIdAndUserId(taskId, userId)
                .orElseThrow(() -> new IllegalArgumentException("Task not found or access denied: " + taskId));
        task.setCompleted(true);
        task.setCompletedAt(LocalDateTime.now());
        return taskRepository.save(task);
    }

    /** Delete a task. */
    public void deleteTask(String taskId, Long userId) {
        taskRepository.findByIdAndUserId(taskId, userId)
                .orElseThrow(() -> new IllegalArgumentException("Task not found or access denied: " + taskId));
        taskRepository.deleteById(taskId);
    }

    /** Find overdue tasks (not completed, due date passed). */
    public List<Task> findOverdueTasks(Long userId, LocalDateTime now) {
        return taskRepository.findOverdueTasks(userId, now);
    }
}
