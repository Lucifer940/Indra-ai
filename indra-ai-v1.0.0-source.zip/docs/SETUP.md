# INDRA AI — Installation & Setup (v1.0.0)

## Prerequisites

| Tool | Version | Used for |
|---|---|---|
| JDK | 11+ (17 recommended) | All modules |
| Gradle | 7.6 (wrapper included) | Build |
| Android Studio | Hedgehog+ (or Android SDK cmdline tools) | Android app + APK |
| Windows 10/11 | — | Windows app runtime |

## 1. Configure secrets

```bash
cp config/.env.example .env
# Edit .env and set at minimum:
#   INDRA_AI_API_KEY=...            (your AI provider key — server-side only)
#   INDRA_JWT_SECRET=...            (≥32 random bytes; generate: openssl rand -base64 48)
#   INDRA_MEMORY_ENCRYPTION_KEY=... (32 random bytes base64; openssl rand -base64 32)
```

The backend loads `.env` from the project root (see `EnvConfig`). Never commit `.env`.

## 2. Build & test (all modules)

```bash
./gradlew build
./gradlew test
```

## 3. Run the backend

```bash
./gradlew :backend:bootRun
# Health:  http://localhost:8080/api/health
# Register: POST /api/auth/register {"email":"you@example.com","password":"...","displayName":"You"}
# Login:    POST /api/auth/login    {"email":"...","password":"..."}  → {token, user}
```

First registered user can be promoted to ADMIN via SQL:
`UPDATE users SET role='ADMIN' WHERE email='you@example.com';` (SQLite file:
`backend/indra.db` by default).

## 4. Android app

1. Open the project in Android Studio (or use cmdline tools below).
2. Set `local.properties` → `sdk.dir=/path/to/AndroidSdk` (Android Studio does this).
3. In the app: Settings → Backend URL. Emulator: `http://10.0.2.2:8080/api`.
   Real phone: `http://<your-PC-LAN-IP>:8080/api` (same Wi-Fi) or your HTTPS URL.
4. Grant microphone + notification permissions when prompted.

Command-line build (needs Android SDK platform 33 + build-tools 33.0.2):

```bash
export ANDROID_HOME=$HOME/Android/Sdk
./gradlew :android-app:assembleDebug
# APK: android-app/build/outputs/apk/debug/android-app-debug.apk
./gradlew :android-app:bundleRelease   # AAB (needs signing config — see android-app/build.gradle)
```

## 5. Windows app

```bash
./gradlew :windows-app:run
# Or build a runnable jar:
./gradlew :windows-app:jar
# java -jar windows-app/build/libs/windows-app-1.0.0.jar
```

The Windows app is a standard JavaFX app — it runs on any OS with JavaFX for
development, and packages for Windows with `jpackage` (see `scripts/package-windows.sh`).
Voice uses Windows SAPI (built into Windows); on non-Windows dev machines the voice
service reports "unavailable" and text chat still works.

## 6. Pair Android ↔ Windows

1. Log in on both apps with the same account.
2. Windows: Pairing screen → shows code + QR. Android: Pairing screen → scan or enter code.
3. Both apps now sync memories, tasks, history, and settings through the backend.

## 7. Production (PostgreSQL + HTTPS)

- Set profile `prod`, `SPRING_DATASOURCE_URL=jdbc:postgresql://…`, credentials via env.
- Put the backend behind HTTPS (nginx/Caddy reverse proxy or `server.ssl.*`).
- Set `INDRA_CORS_ALLOWED_ORIGINS` to your deployed origins.
- Flyway runs migrations automatically on startup. Back up the DB with your normal
  PostgreSQL backup tooling; SQLite dev DB is a single file (`indra.db`).

## Troubleshooting

- **401 on every call** → token expired (24h) — log in again; check `INDRA_JWT_SECRET`
  didn't change between restarts (use a stable secret in `.env`).
- **AI replies say "not configured"** → `INDRA_AI_API_KEY` missing/invalid in `.env`;
  restart the backend after editing.
- **Android can't reach backend** → emulator needs `10.0.2.2`; phone needs PC LAN IP
  and Windows Firewall to allow port 8080 on your private network.
- **Voice unavailable (Windows)** → SAPI needs a Windows machine with a microphone;
  check Windows Settings → Privacy → Microphone.
