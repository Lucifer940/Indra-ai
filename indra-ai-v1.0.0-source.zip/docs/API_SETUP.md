# INDRA AI — API Setup (v1.0.0)

All keys are **backend-only** (environment variables). The Android/Windows apps never
contain keys. Copy `config/.env.example` to `.env` and fill in what you use.

## Required

| Variable | Purpose | Where to get it |
|---|---|---|
| `INDRA_AI_API_KEY` | AI chat brain (OpenAI-compatible `POST /v1/chat/completions`) | Your AI provider dashboard (OpenAI, Azure OpenAI, OpenRouter, local Ollama via `INDRA_AI_BASE_URL`, etc.) |
| `INDRA_AI_BASE_URL` | Provider base URL (default `https://api.openai.com/v1`) | Provider docs |
| `INDRA_AI_MODEL` | Model name (default `gpt-4o-mini`) | Provider docs |
| `INDRA_JWT_SECRET` | JWT signing secret (≥32 random bytes) | Generate locally: `openssl rand -base64 48` |
| `INDRA_MEMORY_ENCRYPTION_KEY` | AES-256 key for memory encryption (32 bytes base64) | Generate locally: `openssl rand -base64 32` |

## Optional integrations

| Variable | Feature | Notes |
|---|---|---|
| `INDRA_GOOGLE_CLIENT_ID` | Google sign-in (Android + Windows) | Google Cloud Console → OAuth client. Android needs your SHA-1. Without it, email/password login is used. |
| `INDRA_SEARCH_API_KEY` + `INDRA_SEARCH_ENGINE_ID` | Web search & news (`/api/search`, `/api/news`) | Google Programmable Search or Bing Web Search. Without it, search returns a clear "not configured" error — the AI brain still answers from its own knowledge. |
| `INDRA_WEATHER_API_KEY` | Weather (`/api/weather`) | OpenWeatherMap free tier. Without it, weather returns "not configured". |
| `INDRA_IMAGE_API_KEY` | AI image generation (whiteboard → Generate) | Same provider family as chat (e.g. OpenAI Images). Without it, generation reports unavailable. |
| `INDRA_FACEBOOK_APP_ID/SECRET`, `INDRA_INSTAGRAM_*` | Social drafts/publishing | Meta for Developers — requires app review + permissions (`pages_manage_posts`, `instagram_basic`, …). Drafts work without approval; publishing needs approved permissions. |
| `INDRA_WHATSAPP_*` | WhatsApp Business messaging | WhatsApp Business Platform (official API) only. Consumer WhatsApp has no official send API — INDRA uses Android share intents instead. |
| `INDRA_FIREBASE_*` | Phone auth (Android) | Firebase Console. Phone auth is implemented as a documented integration point; email/password + Google are the primary logins in v1.0.0. |

## Provider compatibility

The chat proxy speaks the OpenAI Chat Completions schema, so any compatible endpoint
works by changing `INDRA_AI_BASE_URL` + `INDRA_AI_MODEL` (OpenAI, OpenRouter, Azure
with path mapping, LM Studio, Ollama's OpenAI shim, etc.). Streaming (`/api/chat/stream`)
proxies `text/event-stream` chunks when the provider supports it.

## Security reminders

- Never paste keys into the Android/Windows apps, Gradle files, or git.
- Rotate any key that was ever committed (check `git log -p`).
- Restrict provider keys by IP/model where the provider allows it.
