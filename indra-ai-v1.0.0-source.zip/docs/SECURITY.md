# INDRA AI — Security & Privacy (v1.0.0)

## Threat model (pragmatic)

INDRA AI handles personal data (memories, tasks, chats). The design assumes:
untrusted networks, a shared family PC/phone, and API keys that must never leak.

## Controls implemented

| Area | Implementation |
|---|---|
| Authentication | Email + BCrypt password hashing; JWT access tokens (HS256, 24h expiry, `Authorization: Bearer`). Google sign-in verified server-side against Google's tokeninfo endpoint when `INDRA_GOOGLE_CLIENT_ID` is set. |
| Authorization | Role-based (`ADMIN`, `USER`). Every privileged endpoint checks the role on the backend; the UI hiding a button is never the only control. All data queries are scoped by `userId` from the JWT — users cannot read each other's memories/tasks/chats. |
| API keys | AI/search/weather keys read from environment variables only (`INDRA_AI_API_KEY`, etc.). Never in source, never in the Android/Windows apps, never logged. `.env` is git-ignored. |
| Memory encryption | AES-256-GCM at rest (backend, `INDRA_MEMORY_ENCRYPTION_KEY`). Android local cache encrypted with an Android Keystore AES/GCM key. Windows local cache via DPAPI. Passwords/keys are refused as memories. |
| Transport | HTTPS required in production (terminate at reverse proxy or use `server.ssl.*`). LAN development over HTTP is for trusted networks only — the apps warn when the base URL is plain HTTP. |
| Input safety | Bean validation on all DTOs, length caps, structured errors (`{timestamp,status,error,message,path}`), no stack traces to clients. |
| Rate limiting | Per-IP + per-user limits on `/api/auth/*` and `/api/chat*` (`RateLimitFilter`). |
| Device control | Allowlist only (`PcControlService`, Android intents). No arbitrary shell commands. Destructive actions (delete, send SMS, place call, publish) require explicit in-app confirmation. |
| Logging | No passwords, tokens, keys, or memory contents in logs. AI prompts log only lengths/ids. |
| Sessions | Logout clears local tokens; device revocation (`DELETE /api/devices/{id}`) invalidates pairing. JWTs are stateless — keep expiry short (24h) and rotate `INDRA_JWT_SECRET` on compromise. |
| Backups | Memory export is user-initiated, encrypted file (AES-GCM, user passphrase). Restore requires login as the same user. |

## What INDRA AI will NOT do

- No always-on microphone recording. Voice is push-to-talk; the mic indicator is
  visible while listening; audio is transcribed on-device (Android) or via Windows
  SAPI and only the resulting text leaves the device.
- No WhatsApp/Facebook/Instagram automation, scraping, or unofficial clients.
  Only official share intents / draft preparation / official APIs with your own
  approved app credentials.
- No bypassing Android security (no accessibility-service abuse, no silent SMS/calls).
- No public exposure of a home PC without HTTPS + auth + firewall rules. Pairing is
  outbound from the apps to your backend — the PC never listens on the internet.

## Production checklist

1. Set strong `INDRA_JWT_SECRET` (≥32 random bytes) and `INDRA_MEMORY_ENCRYPTION_KEY`
   (32 random bytes, base64) in the deployment environment — never reuse dev values.
2. Run PostgreSQL profile, enable HTTPS, set `INDRA_CORS_ALLOWED_ORIGINS` to your app origins.
3. Rotate the AI provider key if it was ever committed; check git history.
4. Enable OS firewall rules: only the backend port (443) public; DB port never public.
5. Test: unauthenticated requests → 401; cross-user memory access → 404; oversized
   payloads → 400; rapid auth attempts → 429.
