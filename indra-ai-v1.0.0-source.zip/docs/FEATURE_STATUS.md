# INDRA AI — Feature Status (v1.0.0, honest)

Legend: ✅ Implemented & tested · 🟡 Implemented, needs your API key/account to activate ·
⚠️ Partial / integration point · ❌ Not in v1.0.0 (documented limitation)

| # | Feature | Status | Notes |
|---|---|---|---|
| 3 | AI brain (context, follow-ups, EN/NE, 7 personalities, streaming, error handling) | ✅/🟡 | Brain + personalities + streaming implemented; needs `INDRA_AI_API_KEY` to answer. Offline intent parser works without a key. |
| 4 | Permanent memory (remember/update/delete/clear, encrypted, synced, per-user) | ✅ | AES-GCM at rest, Keystore/DPAPI local caches, memory manager UI on both apps. |
| 5 | Voice (Android STT/TTS, Windows SAPI, indicators, interrupt) | ✅ | Push-to-talk only. Windows voice requires a real Windows machine + mic. |
| 6 | Animated character (blink, eyes, mouth sync, states, expressions) | ✅ | Custom-drawn `IndraCharacterView` (Android) + `IndraCharacterPane` (JavaFX). |
| 7 | Android app (splash, login/register, chat, voice, memory, history, settings, themes, about) | ✅ | Google sign-in activates with `INDRA_GOOGLE_CLIENT_ID`; phone auth is a Firebase integration point (⚠️). |
| 8 | Windows app (dashboard, chat, character, voice, memory, history, files, pairing, logout) | ✅ | JavaFX; voice via SAPI PowerShell bridge. |
| 9 | Android↔Windows pairing + sync (QR/code, revoke) | ✅ | Code + QR payload; sync via backend. |
| 10 | PC control (open/close apps, folders, files, websites, system info) | ✅ | Allowlist + confirmation. No arbitrary shell. |
| 11 | Phone control (open apps, battery, reminders, intents, call/SMS with confirm) | ✅ | Official intents only; SMS/call require confirmation + permission. |
| 12 | WhatsApp (prepare, share via official intents; Business API point) | ⚠️ | Consumer WhatsApp has no official send API — share-intent flow only. Business API needs your Meta account. |
| 13 | Facebook/Instagram (drafts, captions, hashtags; publish via official API) | ⚠️ | Drafts ✅. Publishing needs Meta app approval + your credentials. |
| 14 | Tasks/reminders/alarms/timers (NL parsing, recurring, notifications, sync) | ✅ | `IntentParser` + backend tasks + Android alarms/notifications. Calendar sync needs your Google Calendar OAuth (⚠️ integration point). |
| 15 | Web search & news (summaries, sources, EN/NE) | 🟡 | Real provider calls; needs search key. Without key: clear error, never invented sources. |
| 16 | Weather & navigation (current, forecast, location, maps/directions) | 🟡 | Weather needs OpenWeatherMap key; maps/directions open Google Maps intents (no key needed). |
| 17 | Study assistant (maths, science, translation, grammar, quizzes, notes) | ✅ | Via AI brain + Study personality; document Q&A via file reader + AI. |
| 18 | Coding assistant (Java/Android, bugs, Gradle, tests) | ✅ | Via AI brain + Professional/Study personalities. |
| 19 | File management (select, read, summarise, organise, export/import) | ✅ | Permission-based; destructive ops confirmed. |
| 20 | Whiteboard + AI image generation | ✅/🟡 | Whiteboard ✅; image gen needs `INDRA_IMAGE_API_KEY`. |
| 21 | Music & video (local playback, volume, media controls) | ✅ | Local user-selected files only. |
| 22 | Admin & roles (ADMIN/USER, backend-validated) | ✅ | Admin endpoints + user management; no hardcoded passwords. |
| 23 | Security & privacy | ✅ | See SECURITY.md. |
| 24 | Backend & DB (REST, Flyway, SQLite/PostgreSQL, health, errors) | ✅ | Spring Boot 2.7; migrations V1–V2. |
| 25 | Quality (tests, modular, offline intents, accessibility labels) | ✅ | Unit + integration tests for core/backend. |

## Known limitations in v1.0.0

1. **Phone authentication** — Firebase Phone Auth is not wired end-to-end (needs your
   Firebase project + `google-services.json`). Email/password and Google sign-in are primary.
2. **Calendar sync** — Google Calendar OAuth is an integration point; reminders work
   natively in INDRA without it.
3. **Vector memory search** — relevance uses keyword scoring (no embeddings dependency).
   The `MemoryService` interface allows swapping in vector search without API changes.
4. **Social publishing** — requires Meta app review; drafts are fully functional.
5. **APK/AAB + Windows installer** — build commands provided; producing signed artifacts
   requires your Android SDK / Windows machine and signing key (see SETUP.md).
