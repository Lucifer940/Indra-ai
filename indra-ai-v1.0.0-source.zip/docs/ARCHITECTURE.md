# INDRA AI — Architecture (v1.0.0)

## 1. Design goals

- **One brain, many faces:** Android and Windows are thin clients over a single backend
  brain, so behaviour, memory, and personality are identical everywhere.
- **Keys never ship:** AI/search/weather keys live only in backend environment variables.
- **Shared truth:** `shared-core` (pure Java 11, zero platform deps) holds the domain
  models, personality prompts, the intent parser, crypto helpers, and the HTTP API client
  used by both apps — no duplicated DTOs.
- **Safe by default:** allowlisted device actions, confirmation gates, encrypted memory,
  per-user isolation, JWT auth, rate limiting.

## 2. Module map

| Module | Tech | Responsibility |
|---|---|---|
| `shared-core` | Java 11 library | `Personality`, `MemoryItem`, `TaskItem`, `ConversationTurn`, `ParsedIntent`, `Crypto`, `IndraApiClient` interface, DTOs |
| `backend` | Spring Boot 2.7, Spring Security, JPA, SQLite (dev) / PostgreSQL (prod) | REST API, JWT auth, AI proxy (+SSE streaming), memory service, task service, device pairing, admin, health |
| `android-app` | Java, AGP 7.4, Material, SpeechRecognizer/TTS | Chat, voice, `IndraCharacterView`, memory/tasks/settings/history, pairing, notifications |
| `windows-app` | JavaFX 17 | Dashboard, chat, character, SAPI voice, `PcControlService` (allowlist), whiteboard, files, media |

## 3. Request flow (chat)

```
User types/speaks → App (Android/Windows)
  → POST /api/chat {message, personality, language, conversationId}  (JWT)
  → Backend: load user settings + relevant memories → build system prompt
  → Backend: call AI provider (server-side key) → save turn to history
  → Response {reply, conversationId} → App renders + speaks (TTS)
```

Streaming: `POST /api/chat/stream` returns `text/event-stream`; the provider's SSE
chunks are proxied token-by-token. If the provider doesn't support streaming, the
backend falls back to a single complete response (documented in code).

## 4. Memory model

- **Short-term:** conversation turns in `conversation_turns` (per conversation, capped).
- **Long-term:** `memories` rows — `content` encrypted with AES-256-GCM
  (`INDRA_MEMORY_ENCRYPTION_KEY`, 32-byte base64) before persistence; `category`,
  `importance`, `embedding`-free keyword relevance scoring in `MemoryService`
  (kept dependency-free; swap in vector search later without API changes).
- **Capture rules:** explicit ("remember that…", "my favourite… is…") always saved;
  implicit saving only when the user enabled auto-memory in settings. Passwords/keys
  are rejected by `MemoryService` heuristics and never stored.
- **Sync:** both apps read/write the same backend rows; local Android cache is
  additionally encrypted with an Android Keystore AES/GCM key. Windows uses DPAPI
  (`ProtectedData`) via a PowerShell bridge for its local cache.

## 5. Intent parsing (offline-first)

`IntentParser` (shared-core) classifies local commands before any network call:
reminders, timers, alarms, tasks, open-app, weather, search, remember/forget, time/date,
battery, help. This keeps common actions instant and offline-capable, and gives the
assistant deterministic behaviour for device control. Anything unrecognised goes to the
AI brain. Nepali keywords are supported alongside English.

## 6. Device pairing & sync

1. Windows app shows a pairing code + QR (payload: `indra://pair?code=XXXXXX&host=…`).
2. Android scans/enters the code → `POST /api/devices/pair` (authenticated) binds the
   device row to the user.
3. Sync = same backend tables; `GET /api/devices` lists devices, `DELETE /api/devices/{id}`
   revokes. Transport is HTTPS in production (see SECURITY.md); LAN dev uses HTTP on a
   trusted network only.

## 7. Database

Flyway migrations in `backend/src/main/resources/db/migration/`:
`V1__init.sql` (users, conversations, turns, memories, tasks, devices, settings,
announcements), `V2__indexes.sql`. SQLite for local dev (`jdbc:sqlite`), PostgreSQL
for production — JPA entities are dialect-neutral; switch via `application.yml` profile.

## 8. Why Spring Boot 2.7 + Java 11?

Spring Boot 3 requires Java 17. INDRA AI targets Java 11 so it builds on the widest
range of machines (including Android Studio's bundled JDK 11 and headless CI), with a
documented upgrade path: bump `springBootVersion` to 3.x, set `sourceCompatibility`
to 17, and migrate `javax.*` → `jakarta.*`. JavaFX 17 and AGP 7.4 both run on JDK 11+.

## 9. Security summary

BCrypt passwords, JWT (HS256, 24h), Spring Security filter chain, input validation
(`@Valid`), structured error JSON, rate limiting on `/api/auth/*` and `/api/chat*`,
AES-GCM memory encryption, Keystore/DPAPI local caches, allowlisted PC/Android actions
with confirmation, no secrets in source. Full detail: [SECURITY.md](SECURITY.md).

## 10. Known build environment requirement

The backend module (`:backend`) requires network access to Maven Central (or a
mirror) to resolve Spring Boot, Flyway, and other dependencies. The current sandbox
environment has TLS handshake constraints between JDK 11 and Maven Central that
prevent automatic dependency resolution. To build the backend:

- **Option A (online):** Ensure the machine has internet access and JDK 11 TLS
  compatibility with Maven Central (may require JVM flags or network proxy config).
- **Option B (offline):** Pre-download all Maven dependencies to a local Ivy/Maven
  repository and point `settings.gradle`/`gradle.properties` accordingly.
- **Option C (shadow):** Use the `shared-core`, `android-app`, and `windows-app`
  modules which depend only on `shared-core` — these compile successfully in the
  current environment.

The Android and Windows apps depend only on `shared-core` and can be built and
tested without the backend. The backend provides the REST API and AI proxy; without
it, the apps operate in a limited mode (offline chat with pre-defined responses,
no voice, no memory sync).

## 11. Why Spring Boot 2.7 + Java 11?

(See section 8 above.)

## 12. Security summary

(See section 9 above.)
