package com.indra.sharedcore.util;

import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Base64;

/**
 * AES-256-GCM encryption/decryption utility.
 * Used to encrypt MemoryItem.content before persisting to the backend DB.
 * Keys are 256-bit (32-byte) base64-encoded values.
 * <p>
 * This utility is dependency-free (no BouncyCastle, no JCE extensions beyond JDK 11).
 * It is shared by the backend service and the Android/Windows client caches.
 * <p>
 * <b>Important:</b> The Sun/Oracle JDK 11+ implementation of AES-GCM appends the GCM
 * tag (last 16 bytes) to the ciphertext output of Cipher.doFinal(). This utility relies
 * on that convention: encrypt returns b64(nonce || ciphertext || tag), and decrypt
 * extracts the last 16 bytes as the tag and passes the rest to doFinal for verification.
 * If this convention does not hold on a different JVM, add the BouncyCastle provider.
 */
public final class Crypto {

    private Crypto() { /* utility class */ }

    // ---------- constants ----------

    private static final int KEY_SIZE_BYTES = 32;            // 256 bits
    private static final int GCM_TAG_LEN = 16;               // 128-bit tag
    private static final int NONCE_LEN = 12;                 // 96-bit nonce (recommended)

    /** Default dev key — must be replaced before any real data is stored. */
    private static final String DEFAULT_KEY_B64 = "YmFzZTY0LXRva2VuLXRva2VuLXRva2Vu"
            + "YmFzZTY0LXRva2VuLXRva2VuLXRva2Vu";

    /** Decode a base64 key string; falls back to the dev placeholder. */
    public static byte[] decodeKey(String b64Key) {
        if (b64Key == null || b64Key.trim().isEmpty()) {
            return decodeKey(DEFAULT_KEY_B64);
        }
        String k = b64Key.trim();
        if (k.startsWith("base64:")) k = k.substring("base64:".length());
        byte[] raw = Base64.getDecoder().decode(k);
        if (raw.length != KEY_SIZE_BYTES) {
            throw new IllegalArgumentException(
                    "INDRA_MEMORY_ENCRYPTION_KEY must be a " + KEY_SIZE_BYTES
                    + "-byte base64 string; got " + raw.length + " bytes");
        }
        return raw;
    }

    /** Generate a fresh 32‑byte key and return its base64 string. */
    public static String generateKeyB64() {
        byte[] key = new byte[KEY_SIZE_BYTES];
        new SecureRandom().nextBytes(key);
        return Base64.getEncoder().encodeToString(key);
    }

    /** <b>Encrypt</b> a plaintext string → returns "b64nonce|b64ciphertext||tag".
     *  Convention: Sun JDK doFinal appends the GCM tag (16 bytes) to the ciphertext.
     *  Output format: Base64( nonce || ciphertext || tag ), where the three components
     *  are simply concatenated before base64-encoding, and pipe-separated for parsing.
     *  Example blob: "Y2F0ICAgICAgIB......................"
     */
    public static String encrypt(String plaintext, byte[] key) {
        if (plaintext == null || plaintext.isEmpty()) {
            return null;
        }
        try {
            // 1) Random 12‑byte nonce
            byte[] nonce = new byte[NONCE_LEN];
            new SecureRandom().nextBytes(nonce);

            // 2) Initialise and encrypt
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            GCMParameterSpec spec = new GCMParameterSpec(GCM_TAG_LEN * 8, nonce);
            cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(key, "AES"), spec);

            // 3) doFinal: Sun JDK appends the 16‑byte tag to the ciphertext output
            byte[] ctAndTag = cipher.doFinal(plaintext.getBytes(StandardCharsets.UTF_8));

            // 4) Split: ciphertext = everything except last 16 bytes; tag = last 16 bytes
            byte[] ciphertext = Arrays.copyOfRange(ctAndTag, 0, ctAndTag.length - GCM_TAG_LEN);
            byte[] tag = Arrays.copyOfRange(ctAndTag, ctAndTag.length - GCM_TAG_LEN, ctAndTag.length);

            // 5) Concatenate nonce || ciphertext || tag, then base64-encode
            ByteBuffer bb = ByteBuffer.allocate(NONCE_LEN + ciphertext.length + GCM_TAG_LEN);
            bb.put(nonce);
            bb.put(ciphertext);
            bb.put(tag);
            String b64 = Base64.getEncoder().encodeToString(bb.array());

            return b64; // caller can pipe‑split if they want, but we return the full blob
        } catch (Exception e) {
            throw new RuntimeException("AES-GCM encryption failed", e);
        }
    }

    /** <b>Decrypt</b> the output of encrypt(). Expected format: base64-blob where the
     *  Sun JDK convention of tag‑appended ciphertext is in effect.
     *  The method splits: nonce (first 12 bytes of raw bytes), ct+tag (remaining bytes),
     *  extracts tag from last 16 of ct+tag, then decrypts ciphertext (everything before
     *  the last 16 bytes) with tag verification performed by Sun JDK doFinal.
     */
    public static String decrypt(String cryptoBlob, byte[] key) {
        if (cryptoBlob == null || cryptoBlob.isEmpty()) {
            return null;
        }
        try {
            // Decode the full blob
            byte[] blob = Base64.getDecoder().decode(cryptoBlob);

            // Minimum: nonce (12) + at least tag (16) → at least 28 bytes
            if (blob.length < NONCE_LEN + GCM_TAG_LEN) {
                throw new IllegalArgumentException(
                        "Encrypted blob too short: " + blob.length + " bytes (need at least "
                        + (NONCE_LEN + GCM_TAG_LEN) + ")");
            }

            // Split: first 12 bytes = nonce; rest = ciphertext || tag
            byte[] nonce = Arrays.copyOfRange(blob, 0, NONCE_LEN);
            byte[] ctAndTag = Arrays.copyOfRange(blob, NONCE_LEN, blob.length);

            // Extract ciphertext (all but last 16) and tag (last 16)
            int ctLen = ctAndTag.length - GCM_TAG_LEN;
            byte[] ciphertext = Arrays.copyOfRange(ctAndTag, 0, ctLen);
            byte[] tag = Arrays.copyOfRange(ctAndTag, ctLen, ctAndTag.length);

            // Decrypt: Sun JDK doFinal on ciphertext alone will verify the GCM tag
            // from the last 16 bytes of the input IF we pass the ciphertext+tag combo.
            // Since we have them separate, we concatenate them again for doFinal.
            byte[] combined = new byte[ciphertext.length + tag.length];
            System.arraycopy(ciphertext, 0, combined, 0, ciphertext.length);
            System.arraycopy(tag, 0, combined, ciphertext.length, tag.length);

            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            GCMParameterSpec spec = new GCMParameterSpec(GCM_TAG_LEN * 8, nonce);
            cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key, "AES"), spec);

            byte[] plaintext = cipher.doFinal(combined);
            return new String(plaintext, StandardCharsets.UTF_8);
        } catch (Exception e) {
            throw new RuntimeException("AES-GCM decryption failed", e);
        }
    }

    /** Convenience: encrypt with a base64 key string (reads INDRA_MEMORY_ENCRYPTION_KEY). */
    public static String encryptString(String plaintext, String keyB64) throws Exception {
        byte[] key = decodeKey(keyB64);
        return encrypt(plaintext, key);
    }

    /** Convenience: decrypt with a base64 key string. */
    public static String decryptString(String cryptoBlob, String keyB64) throws Exception {
        byte[] key = decodeKey(keyB64);
        return decrypt(cryptoBlob, key);
    }
}

/* JDK utilities already provide Arrays.copyOfRange; the above class is self-contained.
   The Sun JDK AES-GCM convention (tag appended to doFinal output) is well‑documented
   and works on Oracle OpenJDK 11, 17, 21. If another JVM is used, replace with
   BouncyCastle or switch to AES/CTK + HMAC-SHA256. */
