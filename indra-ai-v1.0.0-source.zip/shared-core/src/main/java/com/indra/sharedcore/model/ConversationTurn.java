package com.indra.sharedcore.model;

import java.util.Date;

/**
 * A conversation turn (short-term history).
 * Kept per-conversation, capped size; the AI brain gets a condensed version.
 */
public class ConversationTurn {
    private String id;               // UUID base64
    private String userId;           // backend-scoped (from JWT)
    private String role;             // "user" or "assistant"
    private String content;          // the message text
    private Date timestamp;

    // Constructors
    public ConversationTurn() { this.timestamp = new Date(); }

    // Getters and setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }

    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }

    public Date getTimestamp() { return timestamp; }
    public void setTimestamp(Date timestamp) { this.timestamp = timestamp; }

    @Override
    public String toString() { return "Turn[" + role + "]: " + (content != null ? content.substring(0, Math.min(60, content.length())) + "..." : ""); }
}
