package com.indra.sharedcore.api;

/**
 * DTO for a paired device (Android ↔ Windows sync).
 */
public class DeviceDto {
    private String id;          // device identifier
    private String deviceType;  // "android" or "windows"
    private String name;        // user-visible name
    private String lastSynced;  // timestamp

    public DeviceDto() {}

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getDeviceType() { return deviceType; }
    public void setDeviceType(String deviceType) { this.deviceType = deviceType; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getLastSynced() { return lastSynced; }
    public void setLastSynced(String lastSynced) { this.lastSynced = lastSynced; }
}
