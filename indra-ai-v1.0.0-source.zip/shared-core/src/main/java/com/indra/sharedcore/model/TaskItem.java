package com.indra.sharedcore.model;

import java.util.Date;

/**
 * A task / reminder / alarm item.
 * Users can create tasks by text or voice; the IntentParser classifies the intent.
 */
public class TaskItem {
    private String id;                         // UUID in base64
    private String title;                      // user-visible title
    private String description;                // free-text (optional)
    private Date dueAt;                        // null = no due date
    private Date reminderAt;                   // when to notify (may equal dueAt)
    private boolean recurring;                 // e.g. every Monday
    private String recurrencePattern;          // e.g. "RRULE:FREQ=WEEKLY;BYDAY=MO"
    private boolean completed;
    private Date completedAt;                  // set when user marks complete
    private Date createdAt;
    private String creatorUserId;              // backend-scoped

    // Constructors
    public TaskItem() {
        this.createdAt = new Date();
        this.completed = false;
    }

    // Getters and setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public Date getDueAt() { return dueAt; }
    public void setDueAt(Date dueAt) { this.dueAt = dueAt; }

    public Date getReminderAt() { return reminderAt; }
    public void setReminderAt(Date reminderAt) { this.reminderAt = reminderAt; }

    public boolean isRecurring() { return recurring; }
    public void setRecurring(boolean recurring) { this.recurring = recurring; }

    public String getRecurrencePattern() { return recurrencePattern; }
    public void setRecurrencePattern(String recurrencePattern) { this.recurrencePattern = recurrencePattern; }

    public boolean isCompleted() { return completed; }
    public void setCompleted(boolean completed) { this.completed = completed; }

    public Date getCompletedAt() { return completedAt; }
    public void setCompletedAt(Date completedAt) { this.completedAt = completedAt; }

    public String getCreatorUserId() { return creatorUserId; }
    public void setCreatorUserId(String creatorUserId) { this.creatorUserId = creatorUserId; }

    public String getStatusLabel() {
        return completed ? "completed" : (dueAt != null ? "active" : "no due date");
    }

    @Override
    public String toString() {
        return "TaskItem{id=" + id + ", title=" + title + ", status=" + getStatusLabel() + "}";
    }
}
