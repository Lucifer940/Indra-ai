package com.indra.sharedcore.model;

import java.util.Date;

/**
 * A long-term memory item saved by the user.
 * Encrypted at rest via Crypto (AES-256-GCM). The plaintext content is encrypted
 * before DB write; decrypted when read back. Android Keystore / Windows DPAPI
 * are used for client-side cache encryption.
 */
public class MemoryItem {
    private String id;                     // UUID in base64
    private String content;                // plaintext — encrypted before DB write
    private String category;               // e.g. "personal", "work", "facts"
    private double importance;             // 0.0 – 1.0
    private Date createdAt;
    private Date lastAccessedAt;
    private int accessCount;               // for LRU-style relevance

    // Constructors
    public MemoryItem() { this.createdAt = new Date(); this.lastAccessedAt = this.createdAt; }

    // Getters and setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public double getImportance() { return importance; }
    public void setImportance(double importance) { this.importance = importance; }

    public Date getCreatedAt() { return createdAt; }
    public void setCreatedAt(Date createdAt) { this.createdAt = createdAt; }

    public Date getLastAccessedAt() { return lastAccessedAt; }
    public void setLastAccessedAt(Date lastAccessedAt) { this.lastAccessedAt = lastAccessedAt; }

    public int getAccessCount() { return accessCount; }
    public void setAccessCount(int accessCount) { this.accessCount = accessCount; }

    @Override
    public String toString() { return "MemoryItem{id=" + id + ", category=" + category + "}"; }
}
