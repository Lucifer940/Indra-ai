package com.indra.sharedcore.api;

/**
 * DTO for user settings/personality preferences.
 */
public class UserSettingsDto {
    private String personality;   // e.g. "Friendly", "Professional"
    private String languageCode;  // e.g. "en", "ne"
    private boolean memoryEnabled; // remember conversations
    private boolean voiceEnabled;  // text-to-speech / speech recognition
    private String theme;         // e.g. "light", "dark"

    public UserSettingsDto() {}

    public String getPersonality() { return personality; }
    public void setPersonality(String personality) { this.personality = personality; }

    public String getLanguageCode() { return languageCode; }
    public void setLanguageCode(String languageCode) { this.languageCode = languageCode; }

    public boolean isMemoryEnabled() { return memoryEnabled; }
    public void setMemoryEnabled(boolean memoryEnabled) { this.memoryEnabled = memoryEnabled; }

    public boolean isVoiceEnabled() { return voiceEnabled; }
    public void setVoiceEnabled(boolean voiceEnabled) { this.voiceEnabled = voiceEnabled; }

    public String getTheme() { return theme; }
    public void setTheme(String theme) { this.theme = theme; }
}
