package com.indra.sharedcore.api;

/**
 * DTO for a task/reminder/alarm item transferred between backend and UI.
 */
public class TaskItemDto {
    private String id;
    private Long userId;
    private String title;
    private String description;
    private java.util.Date dueAt;
    private java.util.Date reminderAt;
    private boolean recurring;
    private String recurrencePattern;
    private boolean completed;
    private java.util.Date completedAt;
    private java.util.Date createdAt;

    public TaskItemDto() {}

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public java.util.Date getDueAt() { return dueAt; }
    public void setDueAt(java.util.Date dueAt) { this.dueAt = dueAt; }

    public java.util.Date getReminderAt() { return reminderAt; }
    public void setReminderAt(java.util.Date reminderAt) { this.reminderAt = reminderAt; }

    public boolean isRecurring() { return recurring; }
    public void setRecurring(boolean recurring) { this.recurring = recurring; }

    public String getRecurrencePattern() { return recurrencePattern; }
    public void setRecurrencePattern(String recurrencePattern) { this.recurrencePattern = recurrencePattern; }

    public boolean isCompleted() { return completed; }
    public void setCompleted(boolean completed) { this.completed = completed; }

    public java.util.Date getCompletedAt() { return completedAt; }
    public void setCompletedAt(java.util.Date completedAt) { this.completedAt = completedAt; }

    public java.util.Date getCreatedAt() { return createdAt; }
    public void setCreatedAt(java.util.Date createdAt) { this.createdAt = createdAt; }
}
