package com.indra.sharedcore.api;

/**
 * DTO for a memory item transferred between backend and UI.
 * Contains decrypted content (the backend decrypts before sending).
 */
public class MemoryItemDto {
    private String id;
    private Long userId;
    private String content;      // decrypted plaintext
    private String category;
    private double importance;
    private java.util.Date createdAt;
    private java.util.Date lastAccessedAt;
    private int accessCount;

    public MemoryItemDto() {}

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public double getImportance() { return importance; }
    public void setImportance(double importance) { this.importance = importance; }

    public java.util.Date getCreatedAt() { return createdAt; }
    public void setCreatedAt(java.util.Date createdAt) { this.createdAt = createdAt; }

    public java.util.Date getLastAccessedAt() { return lastAccessedAt; }
    public void setLastAccessedAt(java.util.Date lastAccessedAt) { this.lastAccessedAt = lastAccessedAt; }

    public int getAccessCount() { return accessCount; }
    public void setAccessCount(int accessCount) { this.accessCount = accessCount; }
}
