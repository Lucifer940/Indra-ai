package com.indra.sharedcore.service;

import com.indra.sharedcore.model.ParsedIntent;
import com.indra.sharedcore.model.ParsedIntent.SubType;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Locale;

/**
 * Offline-first intent parser.
 * Classifies user utterances into concrete actions before any network call.
 * - Remembers/forgets personal facts
 * - Creates tasks/reminders/alarms/timers
 * - Opens/closes apps
 * - Weather/search requests
 * - Battery/status queries
 * - Settings intents
 * Anything unrecognised is Type.UNKNOWN → the AI brain handles it.
 * <p>
 * This keeps common actions instant and offline-capable, and gives the assistant
 * deterministic behaviour for device control. Nepali (Devanagari-adjacent) and
 * English keywords are both supported. The parser is stateless and thread-safe.
 */
public final class IntentParser {

    private IntentParser() { /* utility class */ }

    // ---------- public API ----------

    /**
     * Parse a user utterance. The returned ParsedIntent tells the caller
     * whether to handle this locally (reminder, open app, etc.) or forward
     * to the AI brain.
     *
     * @param text the raw user utterance (English or Nepali-supported keywords)
     * @return a ParsedIntent; never null
     */
    public static ParsedIntent parse(String text) {
        if (text == null || text.trim().isEmpty()) {
            return ParsedIntent.unknown("");
        }
        String lower = text.trim().toLowerCase(Locale.ENGLISH);

        // 0) Quick exits
        if (lower.contains("stop") || lower.contains("quit") || lower.contains("exit")
                || lower.contains("goodbye")) {
            return ParsedIntent.knownSubtype(SubType.HELP, "goodbye");
        }
        if (lower.contains("what") && lower.contains("your name")) {
            return ParsedIntent.knownSubtype(SubType.HELP, "name");
        }
        if (lower.contains("thank") || lower.contains("thanks")) {
            return ParsedIntent.knownSubtype(SubType.HELP, "thanks");
        }

        // 1) Remember / Forget
        if (lower.contains("remember") || lower.contains("i remember")
                || lower.contains("please remember")) {
            String value = extractAfter(lower, "remember");
            return ParsedIntent.recognized(text, SubType.REMEMBER, value, true);
        }
        if (lower.contains("forget") || lower.contains("delete memory")
                || lower.contains("remove memory")) {
            String value = extractAfter(lower, "forget");
            return ParsedIntent.recognized(text, SubType.FORGET, value, true);
        }

        // 2) Reminder / Task
        if (lower.contains("remind me")
                || lower.contains("reminder")
                || lower.contains("set a reminder")) {
            String value = extractAfter(lower, "remind me");
            String time = extractTimePhrase(value);
            return ParsedIntent.recognized(text, SubType.TASK_REMINDER, time, true);
        }

        // 3) Timer
        if (lower.contains("timer")) {
            String after = extractAfter(lower, "timer");
            String duration = extractDuration(after);
            return ParsedIntent.recognized(text, SubType.TIMER, duration, true);
        }

        // 4) Alarm
        if (lower.contains("alarm") || lower.contains("wake me")) {
            String after = extractAfter(lower, "alarm");
            String time = extractTimePhrase(after);
            return ParsedIntent.recognized(text, SubType.ALARM, time, true);
        }

        // 5) Open / Close app
        if (lower.contains("open app") || lower.contains("open application")) {
            String appName = extractAppName(lower);
            return ParsedIntent.recognized(text, SubType.OPEN_APP, appName, true);
        }
        if (lower.contains("close app") || lower.contains("quit app")) {
            String appName = extractAppName(lower);
            return ParsedIntent.recognized(text, SubType.CLOSE_APP, appName, true);
        }

        // 6) Search
        if (lower.contains("search") || lower.contains("find")) {
            String query = extractAfter(lower, "search");
            return ParsedIntent.recognized(text, SubType.SEARCH, query, true);
        }

        // 7) Weather
        if (lower.contains("weather")) {
            String location = extractAfter(lower, "weather");
            return ParsedIntent.recognized(text, SubType.WEATHER, location, true);
        }

        // 8) Battery status
        if (lower.contains("battery")) {
            return ParsedIntent.recognized(text, SubType.BATTERY, null, false);
        }

        // 9) Settings
        if (lower.contains("settings") || lower.contains("preferences")) {
            String target = extractAfter(lower, "settings");
            return ParsedIntent.recognized(text, SubType.SETTINGS, target, true);
        }

        // 10) Help / About
        if (lower.contains("help") || lower.contains("what can you")) {
            return ParsedIntent.knownSubtype(SubType.HELP, "general");
        }

        // 11) Name query
        if (lower.contains("who are you") || lower.contains("your name")) {
            return ParsedIntent.knownSubtype(SubType.HELP, "identity");
        }

        // Fallthrough → unknown → AI brain handles
        return ParsedIntent.unknown(text);
    }

    // ---------- private helpers ----------

    /** Return text after the first occurrence of `keyword` (keyword removed). */
    private static String extractAfter(String text, String keyword) {
        int idx = text.indexOf(keyword);
        if (idx < 0) return null;
        String after = text.substring(idx + keyword.length()).trim();
        return after.isEmpty() ? null : after;
    }

    /** Very small "extract after last keyword" for short phrases. */
    private static String extractLastAfter(String text, String keyword) {
        int idx = text.lastIndexOf(keyword);
        if (idx < 0) return null;
        String after = text.substring(idx + keyword.length()).trim();
        return after.isEmpty() ? null : after;
    }

    /** Extract a time phrase like "9 AM", "3 PM", "tomorrow", "next Monday". */
    private static String extractTimePhrase(String text) {
        if (text == null || text.trim().isEmpty()) return null;
        String t = text.trim();

        // explicit clock with AM/PM
        if (t.matches(".*\\b(?:am|pm|AM|PM)\\b.*")) {
            // normalise to "9 AM" format
            String norm = t.replaceAll("\\s+", " ").toUpperCase(Locale.ENGLISH);
            // strip leading words before the time
            String[] tokens = norm.split(" ");
            StringBuilder out = new StringBuilder();
            boolean foundTime = false;
            for (String tok : tokens) {
                if (foundTime) {
                    out.append(tok).append(" ");
                } else if (tok.matches("\\d{1,2}:?\\d*\\s*(AM|PM)")) {
                    out.append(tok).append(" ");
                    foundTime = true;
                } else if (Character.isDigit(tok.charAt(0))) {
                    // could be just "9" without AM/PM — keep it, will ask user
                    out.append(tok).append(" ");
                }
            }
            if (out.length() > 0) return out.toString().trim();
            return null;
        }

        // "tomorrow"
        if (t.contains("tomorrow")) return "tomorrow";

        // "next Monday" / "every Monday"
        if (t.contains("next") || t.contains("every")) {
            // try to find a day name
            for (DayOfWeek dow : DayOfWeek.values()) {
                if (t.contains(dow.name().toLowerCase())) {
                    return "every " + dow.name().toLowerCase(); // backend will expand
                }
            }
            return "every week"; // fallback
        }

        // plain time like "9 o'clock", "9:30"
        if (t.matches(".*\\b\\d{1,2}(:?\\d{2})?\\s*(o'clock|am|pm)?\\b.*")) {
            // normalise
            String norm = t.replaceAll("[^\\d:]", " ");
            // keep only the number part
            String num = norm.replaceAll("\\s+", " ").trim();
            if (!num.isEmpty()) return num;
        }

        return null; // caller will ask user for clarification
    }

    /** Extract a duration like "10 minutes", "30 seconds", "2 hours". */
    private static String extractDuration(String text) {
        if (text == null || text.trim().isEmpty()) return null;
        String t = text.trim();
        // e.g. "10 minutes", "30 seconds", "2 hours"
        String rex = t.replaceAll("\\s+", " ").toLowerCase(Locale.ENGLISH);
        // simple extraction
        String[] parts = rex.split(" ");
        for (int i = 0; i < parts.length - 1; i++) {
            try {
                int qty = Integer.parseInt(parts[i]);
                if (qty > 0) {
                    String unit = parts[i + 1];
                    if (unit.matches("(minute|min|minutes|seconds|second|hours|hour)")) {
                        return qty + " " + unit + (qty > 1 ? "s" : "");
                    }
                }
            } catch (NumberFormatException ignored) {}
        }
        return null;
    }

    /** Extract an app name after "open app" / "close app". */
    private static String extractAppName(String lower) {
        // common patterns: "open app chrome", "open calculator", "open settings"
        String[] triggers = {"open app", "close app"};
        for (String tr : triggers) {
            int idx = lower.indexOf(tr);
            if (idx >= 0) {
                String after = lower.substring(idx + tr.length()).trim();
                // strip leading articles
                after = after.replaceAll("^\\s*(the|a|an)\\s+", "");
                if (!after.isEmpty()) return after;
            }
        }
        return "unknown app";
    }

    // ---------- "known" sub-intent helpers ----------

    /** Returns a ParsedIntent with Type.RECOGNIZED but a fixed SubType + simple resolved value. */
    private static ParsedIntent knownSubtype(SubType sub, String resolved) {
        return new ParsedIntent(ParsedIntent.Type.RECOGNIZED, sub, resolved, resolved, false);
    }

    // --- Android-specific phrase detection (kept here so both apps share it) ---
    // We add a small helper package-private check; the Windows app can call the same method.
    static boolean openAppPhrase(String lower) {
        return lower.contains("open app") || lower.contains("open application");
    }
}
