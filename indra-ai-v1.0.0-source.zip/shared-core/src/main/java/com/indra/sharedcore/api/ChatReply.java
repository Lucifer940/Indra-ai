package com.indra.sharedcore.api;

import com.indra.sharedcore.model.Personality;

/**
 * DTO for a chat AI response.
 */
public class ChatReply {
    private String reply;
    private Personality personality;
    private String languageCode;
    private String conversationId;
    private java.util.Date timestamp;

    public ChatReply() {
        this.timestamp = new java.util.Date();
    }

    public ChatReply(String reply, Personality personality, String languageCode, String conversationId) {
        this.reply = reply;
        this.personality = personality;
        this.languageCode = languageCode;
        this.conversationId = conversationId;
        this.timestamp = new java.util.Date();
    }

    public String getReply() { return reply; }
    public void setReply(String reply) { this.reply = reply; }
    public Personality getPersonality() { return personality; }
    public void setPersonality(Personality personality) { this.personality = personality; }
    public String getLanguageCode() { return languageCode; }
    public void setLanguageCode(String languageCode) { this.languageCode = languageCode; }
    public String getConversationId() { return conversationId; }
    public void setConversationId(String conversationId) { this.conversationId = conversationId; }
    public java.util.Date getTimestamp() { return timestamp; }
    public void setTimestamp(java.util.Date timestamp) { this.timestamp = timestamp; }
}
