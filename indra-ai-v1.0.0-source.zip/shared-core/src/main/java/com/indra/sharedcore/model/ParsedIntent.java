package com.indra.sharedcore.model;

/**
 * Intent classification result from the offline IntentParser.
 * Used by both apps and the backend to decide: handle locally (reminder, open app, etc.)
 * or send to AI brain.
 */
public class ParsedIntent {

    public enum Type { RECOGNIZED, UNKNOWN }

    private final Type type;
    private final SubType subType;
    private final String rawText;
    private final String resolvedValue;    // e.g. "9 AM", "tomorrow", "calendar"
    private final boolean requiresConfirmation;

    // Sub-types
    public enum SubType {
        NONE,
        REMEMBER,      // "remember that X"
        FORGET,        // "forget X"
        TASK_REMINDER,  // "remind me to X at Y"
        TIMER,         // "set timer for X"
        ALARM,         // "set alarm at X"
        OPEN_APP,      // "open app X"
        CLOSE_APP,     // "close app X"
        SEARCH,        // "search for X"
        WEATHER,       // "weather in X"
        BATTERY,       // "battery level"
        HELP,
        SETTINGS;      // open settings page

        public static SubType fromKeyword(String kw) {
            String lower = (kw == null) ? "" : kw.toLowerCase(java.util.Locale.ENGLISH);
            switch (lower) {
                case "remember": case "memories": return REMEMBER;
                case "forget": case "delete memory": return FORGET;
                case "remind": case "reminder": return TASK_REMINDER;
                case "timer": return TIMER;
                case "alarm": return ALARM;
                case "open": return OPEN_APP;
                case "close": return CLOSE_APP;
                case "search": return SEARCH;
                case "weather": return WEATHER;
                case "battery": return BATTERY;
                case "help": return HELP;
                case "settings": return SETTINGS;
                default: return NONE;
            }
        }
    }

    public ParsedIntent(Type type, SubType subType, String rawText, String resolvedValue, boolean requiresConfirmation) {
        this.type = type;
        this.subType = subType;
        this.rawText = rawText;
        this.resolvedValue = resolvedValue;
        this.requiresConfirmation = requiresConfirmation;
    }

    public Type getType() { return type; }
    public SubType getSubType() { return subType; }
    public String getRawText() { return rawText; }
    public String getResolvedValue() { return resolvedValue; }
    public boolean requiresConfirmation() { return requiresConfirmation; }

    /** Creates a RECOGNIZED intent with a fixed sub-type and resolved value.
     * Used by IntentParser.parse() for quick keyword-based classifications. */
    public static ParsedIntent knownSubtype(SubType sub, String resolved) {
        return new ParsedIntent(Type.RECOGNIZED, sub, resolved, resolved, false);
    }

    /** Same as knownSubtype but returns an UNKNOW intent when the text doesn't match
     * any keyword pattern. Used as a fallback in IntentParser.parse(). */
    public static ParsedIntent unknown(String rawText) {
        return new ParsedIntent(Type.UNKNOWN, SubType.NONE, rawText, null, false);
    }

    /** Same as recognized() but with a simple resolved value. */
    public static ParsedIntent recognized(String rawText, SubType subType, String resolvedValue, boolean requiresConfirmation) {
        return new ParsedIntent(Type.RECOGNIZED, subType, rawText, resolvedValue, requiresConfirmation);
    }

    @Override
    public String toString() {
        return "ParsedIntent{type=" + type + ", subType=" + subType + ", resolved=" + resolvedValue + "}";
    }
}
