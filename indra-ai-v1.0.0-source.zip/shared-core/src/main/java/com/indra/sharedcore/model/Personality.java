package com.indra.sharedcore.model;

import java.util.Locale;

/**
 * INDRA AI Personality configuration.
 * Each mode has a prompt prefix that steers the AI brain's responses.
 * The Personality enum stores the active mode, the mode name, and the greeting.
 * Personality is remembered per user across sessions (backend persistence).
 */
public enum Personality {
    FRIENDLY("Friendly Assistant", "You are a warm, friendly, chatty personal assistant. "
            + "Use a first-name basis, ask about the user's day, keep it light and conversational."),
    PROFESSIONAL("Professional Assistant", "You are a professional personal assistant. "
            + "Be concise, structured, and direct. Use formal language and complete sentences."),
    FUNNY("Funny Assistant", "You are a witty, humorous personal assistant. "
            + "Crack light jokes, play friendly wordplay, keep the mood cheerful."),
    STUDY("Study Assistant", "You are a patient study tutor. "
            + "Explain concepts step by step, give examples, quiz the user, encourage questions."),
    MOTIVATIONAL("Motivational Assistant", "You are an encouraging motivator. "
            + "Offer daily affirmations, goal tracking, small wins, progress nudges."),
    DRAMATIC("Dramatic & Entertaining", "You are a theatrical storyteller. "
            + "Express emotions vividly, frame answers like a show, be dramatic and engaging."),
    AFFECTIONATE("Affectionate Companion", "You are a caring companion who remembers personal details. "
            + "Show warmth, check in on wellbeing, use affectionate but appropriate language."),
    UNSET("Unset", "");

    private final String displayName;
    private final String systemPromptPrefix;

    Personality(String displayName, String systemPromptPrefix) {
        this.displayName = displayName;
        this.systemPromptPrefix = systemPromptPrefix;
    }

    public String getDisplayName() { return displayName; }

    public String getSystemPromptPrefix() { return systemPromptPrefix; }

    public static Personality fromDisplayName(String display) {
        for (Personality p : values()) {
            if (p.displayName.equalsIgnoreCase(display)) return p;
        }
        return UNSET;
    }

    @Override
    public String toString() { return displayName; }
}
