package com.indra.sharedcore.api;

import com.indra.sharedcore.model.*;
import java.io.IOException;
import java.util.List;

/**
 * INDRA AI REST API client — pure Java, shared by Android, Windows, and backend tests.
 * <p>
 * This client talks to the backend over HTTPS. The base URL is configured per-platform
 * (Android: http://10.0.2.2:8080/api on emulator; Windows: http://localhost:8080/api;
 * production: HTTPS URL).
 * <p>
 * <b>Never store API keys in this client.</b> The AI provider key lives only in the backend
 * environment (INDRA_AI_API_KEY). This client only sends the user's JWT token.
 * <p>
 * All methods throw IndraApiException on HTTP or parse errors. The caller must
 * decide whether to retry, fall back to offline mode, or show an error UI.
 */
public interface IndraApiClient {

    /** Base URL set by each platform at runtime (e.g. via a build config or shared prefs). */
    String getBaseUrl();

    /** Current JWT token (null if not logged in). */
    String getAuthToken();

    /** -----------------------------------------------------------------
     *  Auth endpoints
     * -----------------------------------------------------------------*/

    /** Register a new user. */
    default UserDto register(String email, String password, String displayName)
            throws IndraApiException {
        // POST /api/auth/register
        // In a real build, each platform provides an implementation (OKHttp, HttpClient, etc.)
        throw new IndraApiException("Not implemented: platform-specific client required");
    }

    /** Login. */
    default UserDto login(String email, String password) throws IndraApiException {
        // POST /api/auth/login
        throw new IndraApiException("Not implemented: platform-specific client required");
    }

    /** Logout (invalidate server-side token). */
    default void logout() throws IndraApiException {
        // POST /api/auth/logout
        throw new IndraApiException("Not implemented: platform-specific client required");
    }

    /** -----------------------------------------------------------------
     *  Chat / AI endpoints
     * -----------------------------------------------------------------*/

    /** Send a chat message and get AI response (single-shot, non-streaming). */
    default ChatReply chat(String message, Personality personality, String languageCode,
                           String conversationId) throws IndraApiException {
        // POST /api/chat
        throw new IndraApiException("Not implemented: platform-specific client required");
    }

    /** Streamed chat — returns an Iterable of text chunks. */
    default Iterable<String> chatStream(String message, Personality personality,
                                          String languageCode, String conversationId)
            throws IndraApiException {
        // POST /api/chat/stream
        throw new IndraApiException("Not implemented: platform-specific client required");
    }

    /** -----------------------------------------------------------------
     *  Memory endpoints
     * -----------------------------------------------------------------*/

    /** Save a memory item (content is encrypted by the caller via Crypto before storage). */
    default MemoryItem saveMemory(MemoryItem memory) throws IndraApiException {
        // POST /api/memories
        throw new IndraApiException("Not implemented: platform-specific client required");
    }

    /** Retrieve memories for a user/ conversation. */
    default List<MemoryItem> loadMemories(String category, double minImportance)
            throws IndraApiException {
        // GET /api/memories?category=…&minImportance=…
        throw new IndraApiException("Not implemented: platform-specific client required");
    }

    /** Update a memory (e.g. change importance). */
    default MemoryItem updateMemory(MemoryItem memory) throws IndraApiException {
        // PUT /api/memories/{id}
        throw new IndraApiException("Not implemented: platform-specific client required");
    }

    /** Delete a memory. */
    default void deleteMemory(String memoryId) throws IndraApiException {
        // DELETE /api/memories/{id}
        throw new IndraApiException("Not implemented: platform-specific client required");
    }

    /** Clear all memories for the authenticated user. */
    default void clearAllMemories() throws IndraApiException {
        // DELETE /api/memories
        throw new IndraApiException("Not implemented: platform-specific client required");
    }

    /** -----------------------------------------------------------------
     *  Task / Reminder endpoints
     * -----------------------------------------------------------------*/

    /** Create a task/reminder/alarm. */
    default TaskItem createTask(TaskItem task) throws IndraApiException {
        // POST /api/tasks
        throw new IndraApiException("Not implemented: platform-specific client required");
    }

    /** Load tasks for the user. */
    default List<TaskItem> loadTasks() throws IndraApiException {
        // GET /api/tasks
        throw new IndraApiException("Not implemented: platform-specific client required");
    }

    /** Update a task (mark complete, edit, etc.). */
    default TaskItem updateTask(TaskItem task) throws IndraApiException {
        // PUT /api/tasks/{id}
        throw new IndraApiException("Not implemented: platform-specific client required");
    }

    /** Delete a task. */
    default void deleteTask(String taskId) throws IndraApiException {
        // DELETE /api/tasks/{id}
        throw new IndraApiException("Not implemented: platform-specific client required");
    }

    /** -----------------------------------------------------------------
     *  Device pairing / sync endpoints
     * -----------------------------------------------------------------*/

    /** Initiate device pairing; returns a pairing code. */
    default String initiatePairing(String deviceType) throws IndraApiException {
        // POST /api/devices/pair?type=android|windows
        throw new IndraApiException("Not implemented: platform-specific client required");
    }

    /** Verify a pairing code and bind the device. */
    default void verifyPairing(String code) throws IndraApiException {
        // POST /api/devices/verify?code=…
        throw new IndraApiException("Not implemented: platform-specific client required");
    }

    /** List paired devices. */
    default List<DeviceDto> listDevices() throws IndraApiException {
        // GET /api/devices
        throw new IndraApiException("Not implemented: platform-specific client required");
    }

    /** Revoke a paired device. */
    default void revokeDevice(String deviceId) throws IndraApiException {
        // DELETE /api/devices/{id}
        throw new IndraApiException("Not implemented: platform-specific client required");
    }

    /** -----------------------------------------------------------------
     *  Settings / Personality endpoints
     * -----------------------------------------------------------------*/

    /** Save user preferences (personality, language, etc.). */
    default UserSettingsDto saveSettings(UserSettingsDto settings) throws IndraApiException {
        // PUT /api/settings
        throw new IndraApiException("Not implemented: platform-specific client required");
    }

    /** Load user preferences. */
    default UserSettingsDto loadSettings() throws IndraApiException {
        // GET /api/settings
        throw new IndraApiException("Not implemented: platform-specific client required");
    }

    /** -----------------------------------------------------------------
     *  Health / info
     * -----------------------------------------------------------------*/

    /** Health check. */
    default boolean isHealthy() throws IndraApiException {
        // GET /api/health
        try {
            // Minimal HEAD or GET; implementations may vary.
            // Return true if the backend responds 2xx.
            return handleHealthCheck(getBaseUrl() + "/health");
        } catch (Exception e) {
            return false;
        }
    }

    /** Common health-check helper (implemented by each platform). */
    boolean handleHealthCheck(String url) throws IndraApiException;

    /** -----------------------------------------------------------------
     *  Nested exception
     * -----------------------------------------------------------------*/

    /** Wrapper for all API errors — contains HTTP status, message, and retry hint. */
    class IndraApiException extends Exception {
        private final int httpStatus;

        IndraApiException(String message) {
            super(message);
            this.httpStatus = -1;
        }

        IndraApiException(String message, int httpStatus) {
            super(message);
            this.httpStatus = httpStatus;
        }

        public int getHttpStatus() { return httpStatus; }
    }
}

/* End of shared API client interface. Each platform (android-app, windows-app)
   must provide a concrete implementation (e.g. IndraApiClientOkHttp, IndraApiClientHttpUrlConnection)
   that sets getBaseUrl() and getAuthToken() appropriately. The backend sends JSON
   responses; the platform clients use their preferred HTTP library (OKHttp on Android,
   Java 11 HttpClient on Windows, or a shared OkHttp instance in the backend tests). */
