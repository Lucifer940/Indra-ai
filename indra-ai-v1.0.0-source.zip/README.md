# INDRA AI — Personal AI Assistant (Android + Windows + Java Backend)

**Version:** 1.0.0
**Developer / Creator:** Umesh Chaudhary
**Platforms:** Android (Java) · Windows (JavaFX) · Backend (Spring Boot, Java 11+)
**Languages:** English + Nepali (नेपाली)

INDRA AI is a modular, secure, API-based personal assistant. The Android app and the
Windows desktop app talk to a Java backend over HTTPS. The backend holds the AI API key
server-side, stores encrypted long-term memory, syncs devices, and exposes a clean REST API.
A pure-Java `shared-core` module is shared by all three applications so models, intent
parsing, and API DTOs stay consistent.

---

## Repository layout

```
indra-ai/
├── settings.gradle / build.gradle / gradle.properties
├── shared-core/          # Pure Java 11 — models, personalities, intent parser, crypto, API client
├── backend/              # Spring Boot 2.7 REST API — auth, AI proxy, memory, tasks, devices, admin
├── android-app/          # Android Java app — chat, voice, animated character, memory, tasks, settings
├── windows-app/          # Windows JavaFX app — dashboard, chat, character, voice, PC control, whiteboard
├── config/               # Example configuration (copy to .env / application-local.yml — never commit secrets)
├── docs/                 # Architecture, security, API setup, feature status
└── scripts/              # Build / run helper scripts
```

See [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) for the full design,
[docs/SETUP.md](docs/SETUP.md) for installation, [docs/API_SETUP.md](docs/API_SETUP.md)
for API keys, [docs/SECURITY.md](docs/SECURITY.md) for the security model, and
[docs/FEATURE_STATUS.md](docs/FEATURE_STATUS.md) for an honest per-feature status table.

---

## Quick start (backend first)

```bash
# 1) Configure secrets (copy the example, fill in your AI key)
cp config/.env.example .env
# edit .env — set INDRA_AI_API_KEY, INDRA_JWT_SECRET, INDRA_MEMORY_ENCRYPTION_KEY

# 2) Build everything
./gradlew build

# 3) Run the backend (SQLite dev DB, auto-migrated by Flyway)
./gradlew :backend:bootRun
# API: http://localhost:8080/api  ·  Health: http://localhost:8080/api/health
```

Android and Windows apps point at the backend base URL in Settings
(default `http://10.0.2.2:8080/api` on the Android emulator, `http://localhost:8080/api`
on Windows). For a real phone, use your PC's LAN IP or a deployed HTTPS URL.

---

## What INDRA AI does

- **Conversational AI brain** — context-aware chat via an OpenAI-compatible provider,
  proxied through the backend so keys never ship in the apps. 7 personality modes
  (Friendly, Professional, Funny, Study, Motivational, Dramatic, Affectionate companion),
  English/Nepali, streaming responses.
- **Permanent memory** — explicit "remember this" capture, encrypted at rest, searchable,
  editable, deletable, synced between Android and Windows, per-user isolated.
- **Voice** — Android SpeechRecognizer + TextToSpeech; Windows SAPI speech via PowerShell
  bridge. Push-to-talk only — no always-on recording.
- **Animated character** — a custom-drawn futuristic face (blinking, eye tracking, mouth
  animation synced to TTS, idle/listening/thinking/speaking states, expressions).
- **Tasks, reminders, alarms, timers** — natural-language parsing ("remind me tomorrow at
  9 AM…"), notifications, recurring reminders, synced across devices.
- **Study + coding assistants** — step-by-step explanations, quizzes, translation,
  Java/Android code help, bug review, Gradle help.
- **Files, whiteboard, media** — permission-based file reading/summaries, drawing canvas,
  local audio/video playback.
- **Device control (safe)** — allowlisted PC operations and Android intents only, with
  explicit confirmation for destructive or consequential actions. No arbitrary shell
  execution, no WhatsApp/Facebook automation that violates platform rules — official
  share intents and draft preparation only.
- **Search, news, weather, maps** — via configurable providers; sources cited; unverifiable
  info is labelled as such.
- **Admin + roles** — Administrator / Normal user, backend-validated, no hardcoded passwords.

---

## Honest limitations (read this)

Some features need third-party accounts/approvals that only you can create:
AI provider key, Google OAuth client ID, Facebook/Instagram app approval, WhatsApp
Business API, Firebase (phone auth), weather/search provider keys. The code implements
the real integration points and fails with clear errors when unconfigured — it never
pretends a service worked when it didn't. See [docs/FEATURE_STATUS.md](docs/FEATURE_STATUS.md).

Android APK/AAB and a Windows installer require an Android SDK / Windows machine to
produce; exact commands are in [docs/SETUP.md](docs/SETUP.md). The backend and shared
core build and test in CI/headless environments.

---

## License / credit

© 2026 Umesh Chaudhary. INDRA AI v1.0.0.
